from dataclasses import dataclass
from typing import List
import httpx

from app.config.settings import settings


@dataclass
class Unit:
    id: str
    title: str
    district: str
    price_per_night: int
    max_guests: int
    description: str


class ExelyService:
    """Integration layer for Exely PMS.

    Current implementation uses demo data. Replace methods with real Exely PMS API calls
    after Exely provides credentials and endpoint documentation for your account.
    """

    def __init__(self) -> None:
        self.base_url = settings.exely_base_url.rstrip("/")
        self.api_key = settings.exely_api_key

    async def search_available_units(
        self,
        check_in: str,
        check_out: str,
        guests: int,
    ) -> List[Unit]:
        # TODO: Replace with real Exely availability/rate endpoint.
        demo_units = [
            Unit(
                id="apt-001",
                title="1-комнатная квартира, центр",
                district="Центр / Мирабад",
                price_per_night=550000,
                max_guests=2,
                description="Чистая квартира рядом с центром, Wi-Fi, кондиционер.",
            ),
            Unit(
                id="apt-002",
                title="2-комнатная квартира, Ц-1",
                district="Ц-1 / Юнусабад",
                price_per_night=750000,
                max_guests=4,
                description="Для семьи или командировки, рядом кафе и магазины.",
            ),
        ]
        return [unit for unit in demo_units if unit.max_guests >= guests]

    async def create_booking(
        self,
        unit_id: str,
        check_in: str,
        check_out: str,
        guests: int,
        guest_name: str,
        phone: str,
        comment: str | None = None,
    ) -> dict:
        # TODO: Replace with real Exely reservation creation endpoint.
        # Example structure for future implementation:
        # async with httpx.AsyncClient(timeout=20) as client:
        #     response = await client.post(
        #         f"{self.base_url}/reservations",
        #         headers={"Authorization": f"Bearer {self.api_key}"},
        #         json={...},
        #     )
        #     response.raise_for_status()
        #     return response.json()
        return {
            "external_booking_id": f"demo-{unit_id}",
            "status": "pending_manager_confirmation",
        }

    async def get_booking_status(self, booking_id: str) -> dict:
        # TODO: Replace with real Exely booking status endpoint.
        return {"booking_id": booking_id, "status": "pending"}
