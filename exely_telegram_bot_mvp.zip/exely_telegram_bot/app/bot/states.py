from aiogram.fsm.state import State, StatesGroup


class BookingFlow(StatesGroup):
    waiting_for_check_in = State()
    waiting_for_check_out = State()
    waiting_for_guests = State()
    choosing_unit = State()
    waiting_for_name = State()
    waiting_for_phone = State()
    waiting_for_comment = State()
