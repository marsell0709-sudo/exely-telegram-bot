from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import main_menu, manager_booking_keyboard, unit_keyboard
from app.bot.states import BookingFlow
from app.config.settings import settings
from app.services.exely import ExelyService

router = Router()
exely = ExelyService()


@router.message(F.text == "/start")
async def start(message: Message) -> None:
    await message.answer(
        "Здравствуйте! Я помогу подобрать квартиру и оформить заявку на бронь.",
        reply_markup=main_menu(),
    )


@router.message(F.text == "🏠 Найти квартиру")
async def find_apartment(message: Message, state: FSMContext) -> None:
    await state.clear()
    await state.set_state(BookingFlow.waiting_for_check_in)
    await message.answer("Введите дату заезда в формате ДД.ММ.ГГГГ. Например: 28.06.2026")


@router.message(BookingFlow.waiting_for_check_in)
async def set_check_in(message: Message, state: FSMContext) -> None:
    await state.update_data(check_in=message.text.strip())
    await state.set_state(BookingFlow.waiting_for_check_out)
    await message.answer("Введите дату выезда в формате ДД.ММ.ГГГГ. Например: 30.06.2026")


@router.message(BookingFlow.waiting_for_check_out)
async def set_check_out(message: Message, state: FSMContext) -> None:
    await state.update_data(check_out=message.text.strip())
    await state.set_state(BookingFlow.waiting_for_guests)
    await message.answer("Сколько гостей будет проживать?")


@router.message(BookingFlow.waiting_for_guests)
async def set_guests(message: Message, state: FSMContext) -> None:
    if not message.text.isdigit() or int(message.text) <= 0:
        await message.answer("Введите количество гостей цифрой. Например: 2")
        return

    guests = int(message.text)
    await state.update_data(guests=guests)
    data = await state.get_data()

    units = await exely.search_available_units(
        check_in=data["check_in"],
        check_out=data["check_out"],
        guests=guests,
    )

    if not units:
        await message.answer("На эти даты свободных объектов нет. Попробуйте другие даты.")
        await state.clear()
        return

    await state.set_state(BookingFlow.choosing_unit)
    await message.answer("Нашёл доступные варианты:")

    for unit in units:
        text = (
            f"🏠 {unit.title}\n"
            f"Район: {unit.district}\n"
            f"Цена: {unit.price_per_night:,} сум / ночь\n"
            f"Гостей: до {unit.max_guests}\n\n"
            f"{unit.description}"
        ).replace(",", " ")
        await message.answer(text, reply_markup=unit_keyboard(unit.id))


@router.callback_query(F.data.startswith("book:"))
async def choose_unit(callback: CallbackQuery, state: FSMContext) -> None:
    unit_id = callback.data.split(":", maxsplit=1)[1]
    await state.update_data(unit_id=unit_id)
    await state.set_state(BookingFlow.waiting_for_name)
    await callback.message.answer("Введите ваше имя:")
    await callback.answer()


@router.message(BookingFlow.waiting_for_name)
async def set_name(message: Message, state: FSMContext) -> None:
    await state.update_data(guest_name=message.text.strip())
    await state.set_state(BookingFlow.waiting_for_phone)
    await message.answer("Введите номер телефона. Например: +998901234567")


@router.message(BookingFlow.waiting_for_phone)
async def set_phone(message: Message, state: FSMContext) -> None:
    await state.update_data(phone=message.text.strip())
    await state.set_state(BookingFlow.waiting_for_comment)
    await message.answer("Есть комментарий к бронированию? Если нет, напишите: нет")


@router.message(BookingFlow.waiting_for_comment)
async def finish_booking(message: Message, state: FSMContext) -> None:
    comment = "" if message.text.lower().strip() == "нет" else message.text.strip()
    await state.update_data(comment=comment)
    data = await state.get_data()

    booking = await exely.create_booking(
        unit_id=data["unit_id"],
        check_in=data["check_in"],
        check_out=data["check_out"],
        guests=data["guests"],
        guest_name=data["guest_name"],
        phone=data["phone"],
        comment=comment,
    )

    booking_ref = booking["external_booking_id"]
    manager_text = (
        "🆕 Новая заявка на бронь\n\n"
        f"Клиент: {data['guest_name']}\n"
        f"Телефон: {data['phone']}\n"
        f"Объект ID: {data['unit_id']}\n"
        f"Заезд: {data['check_in']}\n"
        f"Выезд: {data['check_out']}\n"
        f"Гостей: {data['guests']}\n"
        f"Комментарий: {comment or '—'}\n"
        f"Exely ref: {booking_ref}"
    )

    await message.bot.send_message(
        chat_id=settings.manager_channel_id,
        text=manager_text,
        reply_markup=manager_booking_keyboard(message.from_user.id, booking_ref),
    )

    await message.answer(
        "Заявка отправлена менеджеру. Скоро мы подтвердим наличие и свяжемся с вами.",
        reply_markup=main_menu(),
    )
    await state.clear()


@router.callback_query(F.data.startswith("manager:"))
async def manager_decision(callback: CallbackQuery) -> None:
    _, action, user_id, booking_ref = callback.data.split(":", maxsplit=3)
    user_id_int = int(user_id)

    if action == "confirm":
        await callback.bot.send_message(user_id_int, f"✅ Ваша бронь подтверждена. Номер заявки: {booking_ref}")
        await callback.message.edit_text(callback.message.text + "\n\nСтатус: подтверждено ✅")
    elif action == "reject":
        await callback.bot.send_message(user_id_int, f"❌ К сожалению, бронь не подтверждена. Номер заявки: {booking_ref}")
        await callback.message.edit_text(callback.message.text + "\n\nСтатус: отклонено ❌")

    await callback.answer("Готово")


@router.message(F.text == "📞 Связаться с менеджером")
async def contact_manager(message: Message) -> None:
    await message.answer("Напишите ваш вопрос сюда. Менеджер получит вашу заявку после бронирования. Для срочной связи укажите ваш номер телефона.")


@router.message(F.text == "ℹ️ Правила проживания")
async def rules(message: Message) -> None:
    await message.answer(
        "Правила проживания:\n"
        "• Заезд после 14:00\n"
        "• Выезд до 12:00\n"
        "• Курение запрещено\n"
        "• Вечеринки запрещены\n"
        "• Документ обязателен при заселении"
    )
