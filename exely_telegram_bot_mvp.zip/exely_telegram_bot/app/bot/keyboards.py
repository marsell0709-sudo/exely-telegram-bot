from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton


def main_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🏠 Найти квартиру")],
            [KeyboardButton(text="📞 Связаться с менеджером"), KeyboardButton(text="ℹ️ Правила проживания")],
        ],
        resize_keyboard=True,
    )


def unit_keyboard(unit_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Забронировать", callback_data=f"book:{unit_id}")]
        ]
    )


def manager_booking_keyboard(user_id: int, booking_ref: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Подтвердить", callback_data=f"manager:confirm:{user_id}:{booking_ref}"),
                InlineKeyboardButton(text="❌ Отклонить", callback_data=f"manager:reject:{user_id}:{booking_ref}"),
            ]
        ]
    )
