from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str
    manager_channel_id: int
    exely_base_url: str = "https://api.exely.com"
    exely_api_key: str = ""
    webhook_url: str = ""
    use_webhook: bool = False

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


settings = Settings()
