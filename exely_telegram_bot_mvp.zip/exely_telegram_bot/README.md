# Exely PMS Telegram Bot MVP

Telegram-бот для клиентов субаренды с интеграцией под Exely PMS.

## Возможности MVP

- выбор дат заезда и выезда;
- выбор количества гостей;
- поиск доступных объектов через Exely service layer;
- создание заявки на бронь;
- уведомление менеджерского Telegram-канала;
- подтверждение/отклонение заявки менеджером;
- уведомление клиента о статусе.

## Запуск

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m app.main
```

## Что нужно настроить

1. Создать Telegram-бота через @BotFather.
2. Добавить бота в менеджерский канал администратором.
3. Узнать ID менеджерского канала.
4. Получить Exely PMS API credentials.
5. Заменить методы в `app/services/exely.py` на реальные API-запросы Exely.

## Где подключать Exely

Файл: `app/services/exely.py`

- `search_available_units()` — доступные объекты;
- `create_booking()` — создание бронирования;
- `get_booking_status()` — статус брони.
